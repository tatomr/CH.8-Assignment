﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace C_Sharp_Date_Sorting_Application
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        string filePath;
        private void openButton_Click(object sender, EventArgs e)
        {
            //Dialog window is opens to select the file with the data
            OpenFileDialog getFile = new OpenFileDialog();
            //Default the file save location to the desktop
            string path = @"C:\Users\Cyberadmin\Downloads"; 
            
            getFile.Filter = "CSV Files| *.csv| Text Files (*.txt) | *.txt| All Files (*.*)|*.*";
            getFile.Title = "SELECT CSV FILE";
            getFile.InitialDirectory = path;
            getFile.CheckFileExists = true;
            getFile.CheckPathExists = true;

            // The filepath is stored in the get variable
            if (getFile.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                label1.Text = getFile.FileName;
                filePath = label1.Text.ToString();
                
            }
        }

        private void loadDataButton_Click(object sender, EventArgs e)
        {
            try
            {
                //Creates the columns in the dataGrid
                DataGridViewRow row = new DataGridViewRow();
                row.CreateCells(dataGridView);
                dataGridView.ColumnCount = 6;
                dataGridView.Columns[0].Name = "First Name";
                dataGridView.Columns[1].Name = "Last Name";
                dataGridView.Columns[2].Name = "DOB";
                dataGridView.Columns[3].Name = "City";
                dataGridView.Columns[4].Name = "State";
                dataGridView.Columns[5].Name = "Date Joined";

                StreamReader inputFile;
                string line;
                int count = 0;

                //Create a delimiter array
                char[] delim = { ',' };
                
                //Uses the System.IO.StreamReader to read the file info
                inputFile = File.OpenText(filePath);


                while (!inputFile.EndOfStream)
                {
                    //Reads the data from the CSV file and adds it to the 'line' variable one line, per iteration
                    line = inputFile.ReadLine();

                    //Array declared and line split into tokens
                    string[] tokens = line.Split(delim);

                    //Member Data displayed in broken up tokens
                    dataGridView.Rows.Add(tokens[0], tokens[1], tokens[2], tokens[3], tokens[4], tokens[5]);

                    //incrementer
                    count++;
                }
                //Close input file
                inputFile.Close();
                label1.Text = count + " lines were processed.";
            }
            catch (Exception ex)
            {
                //Error Message
                MessageBox.Show(ex.Message);
            }
            try
            {
                dataGridView.Rows.Clear();

                //Creates TextBoxColumn in the DataGrid
                DataGridViewRow row = new DataGridViewRow();
                row.CreateCells(dataGridView);
                dataGridView.ColumnCount = 6;
                dataGridView.Columns[0].Name = "First Name";
                dataGridView.Columns[1].Name = "Last Name";
                dataGridView.Columns[2].Name = "DOB";
                dataGridView.Columns[3].Name = "City";
                dataGridView.Columns[4].Name = "State";
                dataGridView.Columns[5].Name = "Date Joined";

                StreamReader inputFile;
                string line;
                int count = 0;

                //Delimiter array
                char[] delim = { ',' };


                //CSV File
                inputFile = File.OpenText(filePath);
                StreamWriter OutputFile = new StreamWriter("ProcessedData.CSV");

                while (!inputFile.EndOfStream)
                {
                    //Reads the lines from the CSV file and adds it to the variable 'Line'.
                    line = inputFile.ReadLine();
                    //Replace the first character with the second character.
                    line = line.Replace(".", "/");
                    line = line.Replace("-", "/");

                    string[] tokens = line.Split(delim);

                   //DOB month name replaced with a numeric
                    string dateOne = tokens[2];

                    dateOne = dateOne.Replace("Jan", "1");
                    dateOne = dateOne.Replace("Feb", "2");
                    dateOne = dateOne.Replace("Mar", "3");
                    dateOne = dateOne.Replace("Apr", "4");
                    dateOne = dateOne.Replace("May", "5");
                    dateOne = dateOne.Replace("Jun", "6");
                    dateOne = dateOne.Replace("Jul", "7");
                    dateOne = dateOne.Replace("Aug", "8");
                    dateOne = dateOne.Replace("Sep", "9");
                    dateOne = dateOne.Replace("Oct", "10");
                    dateOne = dateOne.Replace("Nov", "11");
                    dateOne = dateOne.Replace("Dec", "12");


                    string tempOne = "";
                    string[] dateparts = dateOne.Split('/');

                    if (int.Parse(dateparts[0]) > 12)
                    {
                        //Verifies the first part of the date is the month and not the day of the month. 
                        //If so the first character is the day replace it the month.
                        tempOne = dateparts[1];
                        dateparts[1] = dateparts[0];
                        dateparts[0] = tempOne;
                    }

                    //Verifies if the dates are pre millenial or post millenial 
                    if (int.Parse(dateparts[2]) < 1000)
                    {

                        dateparts[2] = "19" + dateparts[2];
                    }

                    if (dateparts[0].Contains("0"))
                    {
                        if (int.Parse(dateparts[0]) < 10)
                        {
                            dateparts[0].Replace("0", "");
                        }
                    }



                    tokens[2] = dateparts[0] + "/" + dateparts[1] + "/" + dateparts[2];



                    //Change the join month name replaced with a numeric
                    string dateTwo = tokens[5];

                    dateTwo = dateTwo.Replace("Jan", "1");
                    dateTwo = dateTwo.Replace("Feb", "2");
                    dateTwo = dateTwo.Replace("Mar", "3");
                    dateTwo = dateTwo.Replace("Apr", "4");
                    dateTwo = dateTwo.Replace("May", "5");
                    dateTwo = dateTwo.Replace("Jun", "6");
                    dateTwo = dateTwo.Replace("Jul", "7");
                    dateTwo = dateTwo.Replace("Aug", "8");
                    dateTwo = dateTwo.Replace("Sep", "9");
                    dateTwo = dateTwo.Replace("Oct", "10");
                    dateTwo = dateTwo.Replace("Nov", "11");
                    dateTwo = dateTwo.Replace("Dec", "12");


                    string temp2 = "";
                    string[] dateparts2 = dateTwo.Split('/');


                    if (int.Parse(dateparts2[0]) > 12)
                    {
                        //Verifies the first part of the date is the month and not the day of the month. 
                        //If so the first character is the day replace it the month.
                        temp2 = dateparts2[1];
                        dateparts2[1] = dateparts2[0];
                        dateparts2[0] = temp2;
                    }
                    //Verifies if the dates are pre millenial or post millenial 
                    if (int.Parse(dateparts2[2]) < 1000)
                    {

                        dateparts2[2] = "19" + dateparts2[2];
                    }


                    if (dateparts2[0].Contains("0"))
                    {
                        if (int.Parse(dateparts2[0]) < 10)
                        {
                            dateparts2[0] = dateparts2[0].Replace(@"0", "");
                        }
                    }

                    if (dateparts2[1].Contains("0"))
                    {
                        if (int.Parse(dateparts2[1]) < 10)
                        {
                            dateparts2[1] = dateparts2[1].Replace(@"0", "");

                        }
                    }


                    tokens[5] = dateparts2[0] + "/" + dateparts2[1] + "/" + dateparts2[2];

                    dataGridView.Rows.Add(tokens[0], tokens[1], tokens[2], tokens[3], tokens[4], tokens[5]);

                    OutputFile.WriteLine(tokens[0] + "," + tokens[1] + "," + tokens[2] + "," + tokens[3] + "," + tokens[4] + "," + tokens[5]);



                    //Increment line each iteration
                    count++;
                }
                //Closed file
                inputFile.Close();

                label1.Text = "All Dates Standardized to MM/DD/YYYY";

            }
            catch (Exception ex)
            {

                //display an error message
                MessageBox.Show(ex.Message);

            }
        }
    }
}
